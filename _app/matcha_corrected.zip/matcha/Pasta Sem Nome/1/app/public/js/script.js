// JavaScript principal da aplicação
