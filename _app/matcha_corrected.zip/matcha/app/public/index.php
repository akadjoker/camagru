<?php
 

require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/router.php';
