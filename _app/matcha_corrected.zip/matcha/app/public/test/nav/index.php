<?php require_once 'header.php'; ?>
<section class="section">
    <div class="container">
        <h1 class="title">Navbar Test</h1>
        <p>Testar comportamento do avatar e dropdown.</p>
    </div>
</section>
</body>
</html>
